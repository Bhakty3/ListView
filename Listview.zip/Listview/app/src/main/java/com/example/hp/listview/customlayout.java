package com.example.hp.listview;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by hp on 10/26/2018.
 */

public class customlayout extends ArrayAdapter<String>{
    private int [] IMAGES;
    private String [] NAMES;
   private String [] DESCRIPTION;
   private Activity context;
    public customlayout(Activity context,String [] NAMES,String [] DESCRIPTION,int [] IMAGES) {
        super(context,R.layout.customlayout,NAMES);

        this.context=context;
        this.NAMES=NAMES;
        this.DESCRIPTION=DESCRIPTION;
        this.IMAGES=IMAGES;

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View r=convertView;
        ViewHolder viewHolder=null;
        if(r==null)
        {
            LayoutInflater layoutInflater=context.getLayoutInflater();
            r=layoutInflater.inflate(R.layout.customlayout,null,true);
            viewHolder=new ViewHolder(r);
            r.setTag(viewHolder);

        }
        else
        {

            viewHolder=(ViewHolder) r.getTag();
        }
        viewHolder.i1.setImageResource(IMAGES[position]);
        viewHolder.t1.setText(NAMES[position]);
        viewHolder.t2.setText(DESCRIPTION[position]);
        return r;
    }

    class ViewHolder
    {
        TextView t1;
        TextView t2;
        ImageView i1;
        ViewHolder(View v)
        {
            t1=v.findViewById(R.id.textView_name);
            t2=v.findViewById(R.id.textView_description);
            i1=v.findViewById(R.id.imageView1);
        }
    }
}
