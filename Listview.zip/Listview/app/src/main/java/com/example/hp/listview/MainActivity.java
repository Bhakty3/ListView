package com.example.hp.listview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int [] IMAGES={R.drawable.daisy,R.drawable.dollar,R.drawable.jarbera,R.drawable.lily,R.drawable.lotus,R.drawable.rose,R.drawable.sunflower};
    String [] NAMES={"Daisy","Dollar","Jarbera","Lily","Lotus","Rose","Sunflower"};
    String [] DESCRIPTION={"This is a beautiful white flower","This is a beautiful white flower","This is a beautiful white flower","This is a beautiful white flower","This is a beautiful white flower","This is a beautiful white flower","This is a beautiful white flower"};
    ListView listview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       listview=findViewById(R.id.listview);
       customlayout customlayout=new customlayout(this,NAMES,DESCRIPTION,IMAGES);
       listview.setAdapter(customlayout);


    }





    }


